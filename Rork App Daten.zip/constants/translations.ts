export const translations = {
  en: {
    // Navigation
    home: 'Home',
    history: 'History',
    profile: 'Profile',
    settings: 'Settings',
    
    // Home Screen
    calorieTracker: 'CalorieTracker',
    addManually: 'Add Manually',
    aiEstimate: 'AI Estimate',
    todaysEntries: "Today's Entries",
    manual: 'Manual',
    aiEstimateShort: 'AI Estimate',
    kcal: 'kcal',
    remaining: 'remaining',
    consumed: 'consumed',
    
    // Modals
    addCaloriesManually: 'Add Calories Manually',
    foodDescription: 'Food Description',
    calories: 'Calories',
    cancel: 'Cancel',
    add: 'Add',
    edit: 'Edit',
    delete: 'Delete',
    save: 'Save',
    
    // Profile
    yourCalorieJourney: 'Your Calorie Journey',
    dailyGoal: 'Daily Goal',
    achievements: 'Achievements',
    daysTracked: 'Days Tracked',
    goalsHit: 'Goals Hit',
    currentStreak: 'Current Streak',
    statistics: 'Statistics',
    totalCaloriesLogged: 'Total Calories Logged',
    averageDailyIntake: 'Average Daily Intake',
    goalAchievementRate: 'Goal Achievement Rate',
    bestStreak: 'Best Streak',
    badges: 'Badges',
    resetData: 'Reset Data',
    
    // Settings
    language: 'Language',
    profilePicture: 'Profile Picture',
    changeProfilePicture: 'Change Profile Picture',
    
    // Languages
    english: 'English',
    german: 'German',
    spanish: 'Spanish',
    
    // Common
    loading: 'Loading...',
    success: 'Success',
    error: 'Error',
    confirm: 'Confirm',
    days: 'days',
  },
  de: {
    // Navigation
    home: 'Start',
    history: 'Verlauf',
    profile: 'Profil',
    settings: 'Einstellungen',
    
    // Home Screen
    calorieTracker: 'Kalorienzähler',
    addManually: 'Manuell hinzufügen',
    aiEstimate: 'KI-Schätzung',
    todaysEntries: 'Heutige Einträge',
    manual: 'Manuell',
    aiEstimateShort: 'KI-Schätzung',
    kcal: 'kcal',
    remaining: 'verbleibend',
    consumed: 'verbraucht',
    
    // Modals
    addCaloriesManually: 'Kalorien manuell hinzufügen',
    foodDescription: 'Lebensmittelbeschreibung',
    calories: 'Kalorien',
    cancel: 'Abbrechen',
    add: 'Hinzufügen',
    edit: 'Bearbeiten',
    delete: 'Löschen',
    save: 'Speichern',
    
    // Profile
    yourCalorieJourney: 'Deine Kaloriereise',
    dailyGoal: 'Tagesziel',
    achievements: 'Erfolge',
    daysTracked: 'Verfolgte Tage',
    goalsHit: 'Erreichte Ziele',
    currentStreak: 'Aktuelle Serie',
    statistics: 'Statistiken',
    totalCaloriesLogged: 'Gesamte protokollierte Kalorien',
    averageDailyIntake: 'Durchschnittliche tägliche Aufnahme',
    goalAchievementRate: 'Zielerreichungsrate',
    bestStreak: 'Beste Serie',
    badges: 'Abzeichen',
    resetData: 'Daten zurücksetzen',
    
    // Settings
    language: 'Sprache',
    profilePicture: 'Profilbild',
    changeProfilePicture: 'Profilbild ändern',
    
    // Languages
    english: 'Englisch',
    german: 'Deutsch',
    spanish: 'Spanisch',
    
    // Common
    loading: 'Laden...',
    success: 'Erfolg',
    error: 'Fehler',
    confirm: 'Bestätigen',
    days: 'Tage',
  },
  es: {
    // Navigation
    home: 'Inicio',
    history: 'Historial',
    profile: 'Perfil',
    settings: 'Configuración',
    
    // Home Screen
    calorieTracker: 'Contador de Calorías',
    addManually: 'Agregar Manualmente',
    aiEstimate: 'Estimación IA',
    todaysEntries: 'Entradas de Hoy',
    manual: 'Manual',
    aiEstimateShort: 'Estimación IA',
    kcal: 'kcal',
    remaining: 'restantes',
    consumed: 'consumidas',
    
    // Modals
    addCaloriesManually: 'Agregar Calorías Manualmente',
    foodDescription: 'Descripción del Alimento',
    calories: 'Calorías',
    cancel: 'Cancelar',
    add: 'Agregar',
    edit: 'Editar',
    delete: 'Eliminar',
    save: 'Guardar',
    
    // Profile
    yourCalorieJourney: 'Tu Viaje de Calorías',
    dailyGoal: 'Meta Diaria',
    achievements: 'Logros',
    daysTracked: 'Días Rastreados',
    goalsHit: 'Metas Alcanzadas',
    currentStreak: 'Racha Actual',
    statistics: 'Estadísticas',
    totalCaloriesLogged: 'Total de Calorías Registradas',
    averageDailyIntake: 'Ingesta Diaria Promedio',
    goalAchievementRate: 'Tasa de Logro de Metas',
    bestStreak: 'Mejor Racha',
    badges: 'Insignias',
    resetData: 'Restablecer Datos',
    
    // Settings
    language: 'Idioma',
    profilePicture: 'Foto de Perfil',
    changeProfilePicture: 'Cambiar Foto de Perfil',
    
    // Languages
    english: 'Inglés',
    german: 'Alemán',
    spanish: 'Español',
    
    // Common
    loading: 'Cargando...',
    success: 'Éxito',
    error: 'Error',
    confirm: 'Confirmar',
    days: 'días',
  },
};

export type Language = keyof typeof translations;
export type TranslationKey = keyof typeof translations.en;