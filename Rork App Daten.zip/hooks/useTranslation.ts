import { useCalories } from '@/hooks/calorie-store';
import { translations, TranslationKey } from '@/constants/translations';

export function useTranslation() {
  const { settings } = useCalories();
  const currentLanguage = settings.language || 'en';
  
  const t = (key: TranslationKey): string => {
    return translations[currentLanguage][key] || translations.en[key] || key;
  };
  
  return { t, currentLanguage };
}