import AsyncStorage from '@react-native-async-storage/async-storage';
import createContextHook from '@nkzw/create-context-hook';
import { useCallback, useEffect, useMemo, useState } from 'react';
import { DailyEntry, CalorieEntry, UserSettings, HistoryPeriod } from '@/types/calorie';

const STORAGE_KEYS = {
  SETTINGS: 'calorie_settings',
  ENTRIES: 'calorie_entries',
};

const getToday = () => new Date().toISOString().split('T')[0];

export const [CalorieProvider, useCalories] = createContextHook(() => {
  const [settings, setSettings] = useState<UserSettings>({
    dailyCalorieGoal: 2000,
    isOnboarded: false,
    language: 'en',
  });
  const [dailyEntries, setDailyEntries] = useState<Record<string, DailyEntry>>({});
  const [isLoading, setIsLoading] = useState(true);

  const loadData = useCallback(async () => {
    try {
      const [settingsData, entriesData] = await Promise.all([
        AsyncStorage.getItem(STORAGE_KEYS.SETTINGS),
        AsyncStorage.getItem(STORAGE_KEYS.ENTRIES),
      ]);

      if (settingsData) {
        setSettings(JSON.parse(settingsData));
      }

      if (entriesData) {
        setDailyEntries(JSON.parse(entriesData));
      }
    } catch (error) {
      console.error('Failed to load data:', error);
    } finally {
      setIsLoading(false);
    }
  }, []);

  // Load data on mount
  useEffect(() => {
    loadData();
  }, [loadData]);

  const saveSettings = useCallback(async (newSettings: UserSettings) => {
    try {
      await AsyncStorage.setItem(STORAGE_KEYS.SETTINGS, JSON.stringify(newSettings));
      setSettings(newSettings);
    } catch (error) {
      console.error('Failed to save settings:', error);
    }
  }, []);

  const saveEntries = useCallback(async (entries: Record<string, DailyEntry>) => {
    try {
      await AsyncStorage.setItem(STORAGE_KEYS.ENTRIES, JSON.stringify(entries));
      setDailyEntries(entries);
    } catch (error) {
      console.error('Failed to save entries:', error);
    }
  }, []);

  const getTodayEntry = useCallback((): DailyEntry => {
    const today = getToday();
    return dailyEntries[today] || {
      date: today,
      consumed: 0,
      goal: settings.dailyCalorieGoal,
      entries: [],
    };
  }, [dailyEntries, settings.dailyCalorieGoal]);

  const addCalorieEntry = useCallback(async (description: string, calories: number, source: 'manual' | 'ai') => {
    const today = getToday();
    const entry: CalorieEntry = {
      id: Date.now().toString(),
      description,
      calories,
      timestamp: Date.now(),
      source,
    };

    const currentEntry = getTodayEntry();
    const updatedEntry: DailyEntry = {
      ...currentEntry,
      consumed: currentEntry.consumed + calories,
      goal: settings.dailyCalorieGoal,
      entries: [...currentEntry.entries, entry],
    };

    const updatedEntries = {
      ...dailyEntries,
      [today]: updatedEntry,
    };

    await saveEntries(updatedEntries);
  }, [dailyEntries, settings.dailyCalorieGoal, getTodayEntry, saveEntries]);

  const updateDailyGoal = useCallback(async (goal: number) => {
    const newSettings = { ...settings, dailyCalorieGoal: goal };
    await saveSettings(newSettings);
    
    // Update today's entry goal
    const today = getToday();
    const todayEntry = getTodayEntry();
    const updatedEntries = {
      ...dailyEntries,
      [today]: { ...todayEntry, goal },
    };
    await saveEntries(updatedEntries);
  }, [settings, dailyEntries, getTodayEntry, saveSettings, saveEntries]);

  const completeOnboarding = useCallback(async (dailyGoal: number) => {
    const newSettings = {
      ...settings,
      dailyCalorieGoal: dailyGoal,
      isOnboarded: true,
    };
    await saveSettings(newSettings);
  }, [saveSettings, settings]);

  const getHistoryData = useCallback((period: HistoryPeriod) => {
    const today = new Date();
    const entries: DailyEntry[] = [];
    
    let days = 7;
    if (period === 'month') days = 30;
    if (period === 'year') days = 365;

    for (let i = days - 1; i >= 0; i--) {
      const date = new Date(today);
      date.setDate(date.getDate() - i);
      const dateStr = date.toISOString().split('T')[0];
      
      entries.push(dailyEntries[dateStr] || {
        date: dateStr,
        consumed: 0,
        goal: settings.dailyCalorieGoal,
        entries: [],
      });
    }

    return entries;
  }, [dailyEntries, settings.dailyCalorieGoal]);

  const getAllEntries = useCallback((): DailyEntry[] => {
    return Object.values(dailyEntries).filter((entry: DailyEntry) => entry.entries.length > 0);
  }, [dailyEntries]);

  const resetAllData = useCallback(async () => {
    try {
      await AsyncStorage.multiRemove([STORAGE_KEYS.SETTINGS, STORAGE_KEYS.ENTRIES]);
      setSettings({
        dailyCalorieGoal: 2000,
        isOnboarded: false,
        language: 'en',
      });
      setDailyEntries({});
    } catch (error) {
      console.error('Failed to reset data:', error);
    }
  }, []);

  const editCalorieEntry = useCallback(async (entryId: string, description: string, calories: number) => {
    const today = getToday();
    const currentEntry = getTodayEntry();
    
    const updatedEntries = currentEntry.entries.map(entry => 
      entry.id === entryId 
        ? { ...entry, description, calories }
        : entry
    );
    
    const totalCalories = updatedEntries.reduce((sum, entry) => sum + entry.calories, 0);
    
    const updatedEntry: DailyEntry = {
      ...currentEntry,
      consumed: totalCalories,
      entries: updatedEntries,
    };
    
    const updatedDailyEntries = {
      ...dailyEntries,
      [today]: updatedEntry,
    };
    
    await saveEntries(updatedDailyEntries);
  }, [dailyEntries, getTodayEntry, saveEntries]);
  
  const deleteCalorieEntry = useCallback(async (entryId: string) => {
    const today = getToday();
    const currentEntry = getTodayEntry();
    
    const updatedEntries = currentEntry.entries.filter(entry => entry.id !== entryId);
    const totalCalories = updatedEntries.reduce((sum, entry) => sum + entry.calories, 0);
    
    const updatedEntry: DailyEntry = {
      ...currentEntry,
      consumed: totalCalories,
      entries: updatedEntries,
    };
    
    const updatedDailyEntries = {
      ...dailyEntries,
      [today]: updatedEntry,
    };
    
    await saveEntries(updatedDailyEntries);
  }, [dailyEntries, getTodayEntry, saveEntries]);
  
  const updateLanguage = useCallback(async (language: 'en' | 'de' | 'es') => {
    const newSettings = { ...settings, language };
    await saveSettings(newSettings);
  }, [settings, saveSettings]);
  
  const updateProfilePicture = useCallback(async (profilePicture: string) => {
    const newSettings = { ...settings, profilePicture };
    await saveSettings(newSettings);
  }, [settings, saveSettings]);

  return useMemo(() => ({
    settings,
    isLoading,
    todayEntry: getTodayEntry(),
    addCalorieEntry,
    editCalorieEntry,
    deleteCalorieEntry,
    updateDailyGoal,
    updateLanguage,
    updateProfilePicture,
    completeOnboarding,
    getHistoryData,
    getAllEntries,
    resetAllData,
  }), [settings, isLoading, getTodayEntry, addCalorieEntry, editCalorieEntry, deleteCalorieEntry, updateDailyGoal, updateLanguage, updateProfilePicture, completeOnboarding, getHistoryData, getAllEntries, resetAllData]);
});